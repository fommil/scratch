
****************************************************************************
		RoboSport for Windows  Special Information
****************************************************************************


This file contains information that may not be included in your RoboSport
manual.  Please take a few moments to review these additional comments.

____________________________________________________________________________

RoboSport Program Files 
____________________________________________________________________________

The following files will be installed on your hard disk by the RoboSport
Install program:

	ROBO.EXE        - The RoboSport program 
	ROBO.REG        - The RoboSport Registration file
	PLAYER.EXE      - The RoboPlayer program
	ROBOCOLR.PRS    - Required for color 
	ROBOMONO.PRS    - Required for monochrome
	RUBBLE.TWN      - The "Rubble Town" set
	SUBURBS.TWN     - The "Suburbs" set
	COMPUTER.TWN    - The "Computer Town" set
	SNDBLST.DLL     - Creative Labs DLL for SoundBlaster support
	README.TXT      - This file

____________________________________________________________________________

Running in Monochrome mode on a color system
____________________________________________________________________________

You can run RoboSport in Monochrome mode on a color system by including
the option MONO on the command line.  You may want to do this if your 
system is low on memory, as the monochrome graphics require less memory
than the color graphics.  Users with slower machines may also realize an
improvement in performance by running in monochrome mode.  You may add this
on the command line for the "Run..." option of the Program Manager, or use
the "Properties.." option to edit the command line of the RoboSport icon.  
See your Windows documentation for details on these procedures.

____________________________________________________________________________

Windows Modes
____________________________________________________________________________

RoboSport runs best under Windows in Standard Mode.  Running the game from
386 enhanced Mode is not recommended, as game timing may be seriously 
affected. RoboSport will not run under Windows in Real Mode.

If running in 386 enhanced mode, there may be a decrease in performance if
you have many other processes open and running in the background, or if 
Windows begins to use the disk drive for virtual memory.  If you experience
problems, try running under Windows in Standard Mode.
(type WIN/S at the DOS prompt).

RoboSport runs better with standard 16 color video drivers. Use of non-
standard or high-color drivers can lead to memory problems which may affect
the stability of Windows.

If you are still having memory problems running RoboSport on your system,
you may want to add LOWMEM to the Command Line property of RoboSport. The
LOWMEM command will cause RoboSport to skip loading certain animations to
save system memory. The LOWMEM command may be combined with the MONO command
to save further space. The updated Command Line should read:
ROBO.EXE LOWMEM MONO

_________________________________________________________________________

Audio Support
____________________________________________________________________________

*** WINDOWS 3.0 ONLY ***

RoboSport supports the SoundBlaster card from Creative Labs, Inc.
To enable the SoundBlaster, the file SNDBLST.DLL must reside in either
the RoboSport directory, the WINDOWS directory, the WINDOWS/SYSTEM 
directory, or any directory specified by the PATH statement.  

This file is normally copied into your RoboSport directory when RoboSport 
is installed. 

RoboSport also adds these lines to your WIN.INI:
	
	[SoundBlaster]
	Port=220
	Int=7
	DMA=1

These settings are the default, and assume that your Sound Blaster's I/O
address and interrupt are set to 220 (hex) and 7, repectively.  If your
settings are not the same as these, change the values accordingly.  
If you are not sure about the settings, run the TESTSBC program that comes
with every Sound Blaster package.  It helps you check the I/O address and
interrupt settings.

If you do not have a copy of SNDBLST.DLL, contact Creative Labs.

*** WINDOWS 3.1 and WINDOWS with MultiMedia Extensions ***

RoboSport should utilize any sound drivers installed that support .WAV
files.
___________________________________________________________________________

Serial and Modem links
___________________________________________________________________________

When connecting serially at slower baud rates, RoboSport will take much
longer to connect and handshake. If you experience problems with serial
connections, make sure the cable being used is well shielded and if
possible, try a slower speed.
____________________________________________________________________________

Compatibility with other RoboSport versions
____________________________________________________________________________

RoboSport for Windows is compatible for Serial or Modem linked play with
Macintosh and Amiga versions.  However, files generated by the game such 
as saved games, movies, scenarios or teams are not compatible.

Macintosh versions earlier than 1.1 will only connect at 19200 baud. 
When connecting to Macintosh version 1.1, the Macintosh user may have to 
try establishing the serial link TWICE at a given baud rate due to a 
problem with resetting the Macintosh serial port.
____________________________________________________________________________

Notes on NetBIOS compatibility
____________________________________________________________________________

RoboSport will allow network connection on a network that uses NetBIOS.
Check your network installation concerning NetBIOS compatibility.  Note
that for some networks, such as Novell Netware, NetBIOS is an option that
may need to be separately installed. Consult your network documentation.

If you experience problems establishing links with RoboSport on your
network, it may help to note the following points:

- NetBIOS must be present in the system.  This is usually loaded in by
  whatever series of commands boots or connects your network, and the
  exact filenames or options vary by implementation. 

- There should be room for two additional names in the local adapter
  name table.  The number of names allowed on your network is sometimes
  adjustable by a NAMES parameter. Check your network's documentation if
  you have problems.

- There needs to be room for up to four sessions.  This is sometimes 
  adjustable by a SESSIONS parameter, or equivalent.

- There needs to be room for at least two pending Datagrams, and enough
  room to handle pending commands.

- Robosport will add one player name for the Primary. It will also add one 
  group name and one player name for each Secondary involved in a game. 
  RoboSport will not allow the user to enter a name that is already being 
  used by the network.

- Windows does not have to be set up to use the network in order for 
  RoboSport to use NetBIOS (but NetBIOS must still be installed).

